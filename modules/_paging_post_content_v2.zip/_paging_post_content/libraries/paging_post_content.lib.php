<?php
/**
 * ZenCMS Software
 * Author: ZenThang
 * Email: thangangle@yahoo.com
 * Website: http://zencms.vn or http://zenthang.com
 * License: http://zencms.vn/license or read more license.txt
 * Copyright: (C) 2012 - 2013 ZenCMS
 * All Rights Reserved.
 */
class paging_post_content
{
    var $maxchar;
    var $maxpage;
    var $string;
    var $arr_using_count;
    var $arr_show;
    var $num_arr_using_count;
    var $pagecurrent;
    var $now_page;

    function __construct()
    {

        $this->maxchar = 0;
        $this->maxpage = 0;
        $this->string = "";
        $this->arr_using_count = array();
        $this->arr_show = array();
        $this->num_arr_using_count = 0;
        $this->pagecurrent = 1;
    }

    public function setInfo($maxchar = 1000, $string = '')
    {
        $this->string = $string;
        $this->maxchar = $maxchar;
        $this->setArrUsingCount();
        $this->setNumArrUsingCount();
        $this->setMaxPage();
        $this->setArrShow();
    }

    public function setMaxPage()
    {
        if ($this->num_arr_using_count <= $this->maxchar) {
            $this->maxpage = 1;
        } else {
            if ($this->num_arr_using_count % $this->maxchar != 0) {
                $this->maxpage = ceil($this->num_arr_using_count / $this->maxchar);
            } else {
                $this->maxpage = $this->num_arr_using_count / $this->maxchar;
            }
        }
    }

    public function setArrUsingCount()
    {
        $this->arr_using_count = explode(" ", $this->string);
    }

    public function setNumArrUsingCount()
    {
        $this->num_arr_using_count = count($this->arr_using_count);
    }

    public function setArrShow()
    {
        if ($this->maxpage == 1) {

            $this->arr_show[0] = $this->string;
        } else {

            $str_tmp = "";
            $j = 0;
            for ($i = 0; $i < $this->num_arr_using_count; $i++) {

                if ($i % $this->maxchar == 0 && $i != 0) {
                    $this->arr_show[$j] = $str_tmp;
                    $str_tmp = "";
                    $j++;
                }
                $str_tmp .= $this->arr_using_count[$i] . " ";
            }

            if ($j < ($this->maxpage)) {

                $this->arr_show[$j] = $str_tmp;
            }
        }
    }

    public function getStrShow($get_page = 1)
    {
        if (!isset($get_page)) {
            $page = 1;
        } else {
            $page = $get_page;
        }

        if ($page <= 0) {
            $page = 1;
        }
        if ($page > $this->maxpage) {
            $page = $this->maxpage;
        }
        $this->now_page = $page;

        return $this->arr_show[$page - 1];
    }

    public function getArrShow()
    {
        return $this->arr_show;
    }

    public function getNumPage()
    {
        return $this->maxpage;
    }

    public function getMaxPage()
    {
        return $this->maxpage;
    }

    public function navi_page($url = '?page=', $sts = 8)
    {
        if (!$url) $url = '?page=';

        $this->url = $url;

        $sts = round($sts / 2);

        if ($this->maxpage != 1) {

            if ($this->now_page <= $sts) {

                $start = 1;
                $end = $sts * 2;
                $prew_fast = '';
                $next_fast = $end + 1;
                $next_fast = "<span class=\"page nextFastPage\"><a href='" . $this->createUrl($next_fast) . "' title='Trang " . $next_fast . "'>Sau</a></span>";

            } else {

                $start = $this->now_page - $sts;
                $end = $this->now_page + $sts;
                $prew_fast = $start - 1;
                $next_fast = $end + 1;
                $prew_fast = "<span class=\"page prewFastPage\"><a href='" . $this->createUrl($prew_fast) . "' title='Trang " . $prew_fast . "'>Trước</a></span>";
                $next_fast = "<span class=\"page nextFastPage\"><a href='" . $this->createUrl($next_fast) . "' title='Trang " . $next_fast . "'>Sau</a></span>";
            }

            if ($end >= $this->maxpage) {

                $end = $this->maxpage;
                $next_fast = '';
            }

            $navi = '<div class="list_page">';

            $navi .= "<span class=\"page fistPage\"><a href='" . $this->createUrl(1) . "' title='Trang 1'>Đầu</a> " . $prew_fast . "</span>";

            for ($t = $start; $t <= $end; $t++) {

                if ($t == $this->now_page) {

                    $navi .= '<span class="page currentPage"><b class="ipage">' . $t . '</b></span>';

                } else {

                    $navi .= "<span class=\"page\"><a href='" . $this->createUrl($t) . "'>" . $t . "</a></span>";
                }

                $navi .= " ";
            }
            $navi .= "" . $next_fast . "<span class=\"page endPage\"><a href='" . $this->createUrl($this->maxpage) . "' title='Trang " . $this->maxpage . "'>Cuối</a></span>";

            $navi .= "</div>";

            return $navi;

        } else return;
    }

    private function createUrl($num)
    {

        $url = $this->url;

        $match = array();

        $patt = '/\{([a-zA-Z0-9_\-]+)\}/is';

        if (preg_match($patt, $url)) {

            preg_match_all($patt, $url, $match);

            if (isset($match[1][0])) {

                $name = $match[1][0];
            }
            if (!empty($name)) {

                $url = preg_replace($patt, $num, $url);

            } else {
                $url = $url . $num;
            }

        } else {
            $url = $url . $num;
        }

        $base = _HOME . '/' . ROUTER_BEFORE_REWRITE;

        if (ROUTER_BEFORE_REWRITE == '') {

            $base = _HOME;
        }

        return $base . $url;
    }
}



/*
	$string = "adaks anskja lấn lsknal"; 
	$Jpage = new pagination();
	$Jpage->setInfo(1, $string);

	if (!isset($_GET['page'])){
		$page = 1;
	}else{
		$page = $_GET["page"];
	}
	echo $Jpage->getStrShow($page);// return content 
	echo "<hr>";
	echo "Trang: ";
	for($t = 1; $t<= $Jpage->getNumPage(); $t++){
		echo "<a href='?page=".$t."'>".$t."</a>";
		echo " ";   
	}
*/
