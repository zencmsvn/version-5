<?php
/**
 * ZenCMS Software
 * Author: ZenThang
 * Email: thangangle@yahoo.com
 * Website: http://zencms.vn or http://zenthang.com
 * License: http://zencms.vn/license or read more license.txt
 * Copyright: (C) 2012 - 2013 ZenCMS
 * All Rights Reserved.
 */
if (!defined('__ZEN_KEY_ACCESS')) exit('No direct script access allowed');

Class updateModel Extends ZenModel
{


    function chatbox_sql() {

        model()->_update_config(array('chatbox_num_item_per_page' => 10));

        if ($this->table_exist('zen_cms_chatbox')) {
            return true;
        }

        $result = $this->db->query("CREATE TABLE IF NOT EXISTS `zen_cms_chatbox` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `time` int(11) NOT NULL,
  `user_agent` text NOT NULL,
  `group` varchar(100) NOT NULL,
  `edit` int(11) NOT NULL,
  `who_edit` varchar(50) NOT NULL,
  `time_edit` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");

        return $result;
    }

    function get_id_admin()
    {

        $query = $this->db->query("SELECT `id` FROM " . tb() . "users where `perm` = 'admin' order by `id` ASC limit 1");
        if ($this->db->num_row($query)) {
            $user = $this->db->fetch_array($query);
            return $user['id'];
        }
        return false;
    }

    function table_exist($table){

        $sql = "show tables like '".$table."'";
        $res = $this->db->query($sql);
        return ($this->db->num_rows($res) > 0);
    }

    function check_colum_is_exists($table, $colum)
    {
        $exists = false;
        $columns = $this->db->query("show columns from $table");
        while ($c = $this->db->fetch_assoc($columns)) {
            if ($c['Field'] == $colum) {
                $exists = true;
                break;
            }
        }
        return $exists;
    }

}

?>