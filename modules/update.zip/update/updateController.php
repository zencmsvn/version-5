<?php
/**
 * ZenCMS Software
 * Author: ZenThang
 * Email: thangangle@yahoo.com
 * Website: http://zencms.vn or http://zenthang.com
 * License: http://zencms.vn/license or read more license.txt
 * Copyright: (C) 2012 - 2013 ZenCMS
 * All Rights Reserved.
 */
if (!defined('__ZEN_KEY_ACCESS')) exit('No direct script access allowed');

Class updateController Extends ZenController
{

    function index($request_data = array())
    {
        $model = $this->model->get('update');

        $data['page_title'] = 'Update code';

        $data['steps'][1]['name'] = 'Thêm bảng `zen_cma_chatbox`';
        $data['steps'][1]['process'] = FALSE;


        if (isset($_POST['sub'])) {
            if ($model->chatbox_sql()) {
                $data['steps'][1]['process'] = TRUE;
            }

        }

        $this->view->data = $data;
        $this->view->show('update');
    }

}