<?php
/**
 * ZenCMS Software
 * Author: ZenThang
 * Email: thangangle@yahoo.com
 * Website: http://zencms.vn or http://zenthang.com
 * License: http://zencms.vn/license or read more license.txt
 * Copyright: (C) 2012 - 2013 ZenCMS
 * All Rights Reserved.
 */
if (!defined('__ZEN_KEY_ACCESS')) exit('No direct script access allowed');

Class post_navigatorController Extends ZenController
{
    function _run()
    {

        function post_navigator_function($data) {

            global $registry;

            if ($data['type'] != 'post') {

                return $data;
            }

            $model = $registry->model->get('blog');

            $parent = $data['parent'];
            $weight = $data['weight'];

            $next = $model->gets('*', "WHERE `parent` = '$parent' and `type` = 'post' and `weight` >= '$weight' and `id` != '".$data['id']."'", array('weight' => 'ASC', 'time' => 'DESC'), 1);
            $prew = $model->gets('*', "WHERE `parent` = '$parent' and `type` = 'post' and `weight` <= '$weight' and `id` != '".$data['id']."'", array('weight' => 'DESC', 'time' => 'DESC'), 1);

            if (!empty($next[0])) {

                $p_next = $next[0];
            }
            if (!empty($prew[0])) {

                $p_prew = $prew[0];
            }

            $navi = '<div style="margin-top: 20px; padding: 0px 10px">';

            if (!empty($p_prew)) {

                $navi .= '<a href="'.$p_prew['full_url'].'" title="'.$p_prew['title'].'" style="float: left" class="button BgGreen">Bài trước</a>';
            }
            if (!empty($p_next)) {

                $navi .= '<a href="'.$p_next['full_url'].'" title="'.$p_next['title'].'" style="float: right" class="button BgBlue">Bài sau</a>';
            }

            $navi .= '</div>';

            $navi .= '<div style="clear: both"></div>';

            $data['content'] = $data['content'] . $navi;

            return $data;
        }

        run_hook('blog', 'blog_data', 'post_navigator_function', 9999);
    }
}
