<div class="detail_content">
    <h2 class="title border_orange"><a href="<?php echo _HOME ?>/mp3" title="Nghe nhạc online, tải nhạc miễn phí">Nghe nhạc online, tải nhạc miễn phí</a></h2>
    <div class="tip">Chào mừng bạn đến với trang nghe nhạc, tải nhạc online miễn phí của vui9x</div>
    <div class="item">
        <a href="<?php echo _HOME ?>/mp3" title="Album hot">Album hot</a> |
        <a href="<?php echo _HOME ?>/mp3/hotsong" title="Bài hát nổi bật">Nổi bật</a> |
        <a href="<?php echo _HOME ?>/mp3/cat" title="Nhạc theo chủ đề">Chủ đề</a> |
        <a href="<?php echo _HOME ?>/mp3/search" title="Nhạc theo chủ đề">Tìm kiếm</a>
    </div>
</div>