<div class="info">
    Name: <?php echo $fileinfo['name'] ?><br/>
    Size: <?php echo $fileinfo['size'] ?><br/>
    Last Modified: <?php echo $fileinfo['time'] ?><br/>
    Perms: <?php echo $fileinfo['perms'] ?><br/>
</div>