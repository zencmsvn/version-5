<?php
/**
 * name = Thêm sản phẩm
 * icon = admin_general_products
 * position = 80
 */
/**
 * ZenCMS Software
 * Author: ZenThang
 * Email: thangangle@yahoo.com
 * Website: http://zencms.vn or http://zenthang.com
 * License: http://zencms.vn/license or read more license.txt
 * Copyright: (C) 2012 - 2013 ZenCMS
 * All Rights Reserved.
 */
if (!defined('__ZEN_KEY_ACCESS')) exit('No direct script access allowed');

/**
 * load admin model
 */
$model = $obj->model->get('admin');

/**
 * load hook
 */
$obj->hook->get('admin');

load_helper('time');

/**
 * load library
 */
$p = load_library('pagination');
$security = load_library('security');
$seo = load_library('seo');
$upload = load_library('upload');

$data['page_title'] = 'Quản lí sản phẩm';
$tree[] = url(_HOME . '/admin', 'Admin CP');
$tree[] = url(_HOME . '/admin/general', 'Tổng quan');
$tree[] = url(_HOME . '/admin/general/products', $data['page_title']);

$act = '';

if (isset($app[1])) {

    $act = $security->cleanXSS($app[1]);
}

switch ($act) {

    default:

        $products = $model->get_list_products();
        $data['products'] = $products;
        $data['display_tree'] = display_tree($tree);
        $obj->view->data = $data;
        $obj->view->show('admin/general/products/index');
        break;

    case 'released':

        if (!isset($_GET['id'])) {

            redirect(_HOME . '/admin/general/products');
        }

        $update['released'] = 1;

        $model->update_product($_GET['id'], $update);

        redirect(_HOME . '/admin/general/products');
        break;

    case 'edit':

        if(empty($_GET['id'])) {

            redirect(_HOME . '/admin/general/products');
        }

        $product = $model->get_product($_GET['id']);

        if(empty($product)) {

            redirect(_HOME . '/admin/general/products');
        }

        if (isset($_POST['sub'])) {

            if (empty($_POST['name'])) {

                $data['notices'][] = 'Bạn chưa nhập đầy đủ';

            } else {

                $name = h($_POST['name']);
                $version = h($_POST['version']);
                $des = h($_POST['des']);

                $dir = __FILES_PATH . '/products';

                $mkdir = auto_mkdir($dir);

                $config['upload_path'] = $dir . '/' . $mkdir;
                $config['allowed_types'] = 'zip';
                $config['seo_name'] = true;
                $upload->initialize($config);

                if (!$upload->do_upload('file') && !empty($_FILES['file']['name'])) {

                    $data['errors'] = $upload->error;

                } else {

                    $dataup = $upload->data();

                    $url = $mkdir . '/' . $dataup['file_name'];

                    $update['size'] = $dataup['file_size'];

                    if (empty($_FILES['file']['name'])) {

                        $url = $product['url'];
                        $update['size'] = $product['size'];
                    }

                    $update['name'] = $name;
                    $update['version'] = $version;
                    $update['des'] = $des;
                    $update['url'] = $url;
                    $update['time'] = time();


                    if ($model->update_product($_GET['id'], $update)) {

                        if (!empty($_FILES['file']['name'])) {

                            @unlink($product['full_path']);
                        }

                        redirect(_HOME . '/admin/general/products');

                    } else {

                        $data['errors'][] = 'Không thể ghi dữ liệu';
                    }
                }
            }
        }

        $data['product'] = $product;
        $data['display_tree'] = display_tree($tree);
        $obj->view->data = $data;
        $obj->view->show('admin/general/products/edit');

        break;

    case 'new':

        if (isset($_POST['sub'])) {

            if (empty($_POST['name'])) {

                $data['notices'][] = 'Bạn chưa nhập đầy đủ';

            } else {

                $name = h($_POST['name']);
                $version = h($_POST['version']);
                $des = h($_POST['des']);

                $dir = __FILES_PATH . '/products';

                $mkdir = auto_mkdir($dir);

                $config['upload_path'] = $dir . '/' . $mkdir;
                $config['allowed_types'] = 'zip';
                $config['seo_name'] = true;
                $upload->initialize($config);

                if (!$upload->do_upload('file')) {

                    $data['errors'][] = 'Không thể upload file';

                } else {

                    $dataup = $upload->data();

                    $url = $mkdir . '/' . $dataup['file_name'];

                    $insert['name'] = $name;
                    $insert['version'] = $version;
                    $insert['des'] = $des;
                    $insert['url'] = $url;
                    $insert['time'] = time();
                    $insert['size'] = $dataup['file_size'];

                    if ($model->insert_product($insert)) {

                        redirect(_HOME . '/admin/general/products');
                    } else {

                        $data['errors'][] = 'Không thể ghi dữ liệu';
                    }
                }
            }
        }
        $data['page_title'] = 'Thêm sản phẩm mới';
        $data['display_tree'] = display_tree($tree);
        $obj->view->data = $data;
        $obj->view->show('admin/general/products/new');

        break;
    case 'delete':

        $_GET['id'] = (int) $_GET['id'];

        if(empty($_GET['id'])) {

            redirect(_HOME . '/admin/general/products');
        }

        $product = $model->get_product($_GET['id']);

        if (empty($product)) {

            redirect(_HOME . '/admin/general/products');
        }

        if (isset($_POST['sub'])) {

            if ($model->delete_product($_GET['id'])) {

                @unlink($product['full_path']);
            }
            redirect(_HOME . '/admin/general/products');
        }

        $data['product'] = $product;
        $data['page_title'] = 'Xóa';
        $data['display_tree'] = display_tree($tree);
        $obj->view->data = $data;
        $obj->view->show('admin/general/products/delete');
        break;
}
