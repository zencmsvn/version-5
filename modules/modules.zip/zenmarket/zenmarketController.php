<?php
/**
 * ZenCMS Software
 * Author: ZenThang
 * Email: thangangle@yahoo.com
 * Website: http://zencms.vn or http://zenthang.com
 * License: http://zencms.vn/license or read more license.txt
 * Copyright: (C) 2012 - 2013 ZenCMS
 * All Rights Reserved.
 */
if (!defined('__ZEN_KEY_ACCESS')) exit('No direct script access allowed');

class zenmarketController extends ZenController
{

    private $zenmarket = array();

    function index($request_data = array())
    {
        /**
         * load helpers
         */
        load_helper('time');
        load_helper('gadget');

        /**
         * load library
         */
        $security = load_library('security');
        $p = load_library('pagination');
        $bbcode = load_library('bbcode');
        $permission = load_library('permission');
        $permission->set_user($this->user);

        /**
         * get zenmarket model
         */
        $model = $this->model->get('zenmarket');

        if (isset($_GET['_review_recycleBin_']) && is(ROLE_MANAGER)) {

            $model->only_filter_recycle_bin();
        }

        /**
         * get hook
         */
        $this->hook->get('zenmarket');

        /**
         * remove sqli, load id *
         */
        if (isset($request_data[0])) {

            $id = $security->removeSQLI($request_data[0]);

        } else {

            $id = 0;
        }

        $id = (int)$id;

        /**
         * Check zenmarket is exists *
         */
        if ($model->zenmarket_exists($id) == false) {

            $data['page_title'] = 'Error!';
            $data['notices'][] = 'Bài đăng này không tôn tại hoặc đã bị xóa bời người quản lí!';
            $this->view->data = $data;
            $this->view->show('zenmarket/error');
            return false;
        }

        /**
         * If is a zenmarket *
         */
        $zenmarket_data = $model->get_zenmarket_data($id); // load data of zenmarket

        if (empty($zenmarket_data['parent'])) {

            $_SESSION['ss_url_delete_and_back'] = _HOME;

        } else {

            $data_back = $model->get_zenmarket_data($zenmarket_data['parent'], 'url');

            if (isset($data_back['full_url'])) {

                $_SESSION['ss_url_delete_and_back'] = $data_back['full_url'];
            }

        }

        $zenmarket_data['sid'] = $id;

        /**
         * load title zenmarket or home *
         */
        if (isset($zenmarket_data['title'])) {

            $data['page_title'] = $zenmarket_data['title'];

        } else {

            if (isset($zenmarket_data['name'])) {

                $data['page_title'] = $zenmarket_data['name'];

            } else {

                $data['page_title'] = 'Chợ ứng dụng ZenCMS';
            }
        }

        /**
         * if $id = 0 is home
         */
        if ($id == 0) {

            $cats = $model->get_list_zenmarket(0);

            foreach ($cats as $kid => $cat) {

                $cats[$kid]['sub_cat'] = $model->get_list_zenmarket($kid);
            }

            /**
             * lists_in_index hook *
             */
            $data['list'] = $this->hook->loader('lists_in_index', $zenmarket_data);

            $data['page_keyword'] = get_config('keyword');
            $data['page_des'] = get_config('des');
            $data['cats'] = $cats;
            $this->view->data = $data;
            $this->view->show('zenmarket');
            return;
        }

        /**
         * update view
         */
        $model->update_view($zenmarket_data['sid']);

        /**
         * else is a zenmarket *
         */
        if ($zenmarket_data['type'] == 'folder') {
            /**
             * lists_in_folder hook *
             */
            $data['list'] = $this->hook->loader('lists_in_folder', $zenmarket_data);

            /**
             * load manager bar *
             */
            if ($permission->is_manager()) {

                $zenmarket_data['manager_bar'] = $this->hook->loader('folder_manager_bar', $id);

            } else {

                $zenmarket_data['manager_bar'] = array();
            }

            $data['page_more'] = '';
            /**
             * set_page_more_in_folder hook *
             */
            $data['page_more'] = $this->hook->loader('set_page_more_in_folder', $data['page_more']);

        } elseif ($zenmarket_data['type'] == 'post') {

            $data['page_more'] = '';
            /**
             * set_page_more_in_post hook *
             */
            $data['page_more'] = $this->hook->loader('set_page_more_in_post', $data['page_more']);

            $data['page_more'] .= gadget_TinymceEditer('bbcode_mini', true);

            /**
             * lists_in_post hook *
             */
            $data['list'] = $this->hook->loader('lists_in_post', $zenmarket_data);

            /**
             * load manager bar *
             */
            if ($permission->is_manager()) {

                $zenmarket_data['manager_bar'] = $this->hook->loader('post_manager_bar', $id);

            } else {

                $zenmarket_data['manager_bar'] = array();
            }

        } else {

            $data['page_title'] = 'Error!';
            $data['notices'][] = 'Bài đăng này đã bị xóa bời người quản lí!';
            /**
             * lists_in_other hook *
             */
            $data['list'] = $this->hook->loader('lists_in_other', $zenmarket_data);
            $this->view->data = $data;
            $this->view->show('zenmarket/error');
            return false;
        }


        /**
         * load content
         */
        if (isset($zenmarket_data['type_data']) && isset($zenmarket_data['content'])) {
            /**
             * out_content hook *
             */
            $zenmarket_data['content'] = $this->hook->loader('out_content', $zenmarket_data['content']);

            if ($zenmarket_data['type_data'] == 'bbcode') {

                $zenmarket_data['content'] = $bbcode->parse($zenmarket_data['content']);
                /**
                 * out_bbcode_content hook *
                 */
                $zenmarket_data['content'] = $this->hook->loader('out_bbcode_content', $zenmarket_data['content']);
            } else {
                /**
                 * out_html_content hook *
                 */
                $zenmarket_data['content'] = $this->hook->loader('out_html_content', $zenmarket_data['content']);
            }

            $zenmarket_data['content'] = scan_smiles($zenmarket_data['content']);
        }


        $tags = $model->get_tags_zenmarket($zenmarket_data['sid']);

        foreach ($tags as $tag) {

            /**
             * out_tag hook *
             */
            $zenmarket_data['tags'][] = $this->hook->loader('out_tag', $tag);

        }

        // start comments

        if (isset($_POST['sub_comment'])) {

            if ($security->check_token('token_comment')) {

                if (!$security->check_token('captcha_code') and empty($this->user['id'])) {

                    $data['errors'][] = 'Mã xác nhận không chính xác';
                } else {

                    $continous = true;

                    if (isset($this->user['id'])) {

                        $ins_cmt['uid'] = $this->user['id'];
                    } else {

                        $ins_cmt['uid'] = 0;
                    }

                    if (!$ins_cmt['uid']) {

                        if (empty($_POST['name'])) {

                            $data['notices'][] = 'Bạn chưa nhập tên mình';
                            $continous = false;

                        } else {

                            $ins_cmt['name'] = h($_POST['name']);
                        }
                    } else {

                        $ins_cmt['name'] = $this->user['username'];
                    }

                    if (empty($_POST['msg'])) {

                        $data['notices'][] = 'Nội dung comment không được để trống';
                        $continous = false;

                    } else {

                        $ins_cmt['msg'] = h($_POST['msg']);
                        /**
                         * in_msg_comment_content hook *
                         */
                        $ins_cmt['msg'] = $this->hook->loader('in_msg_comment_content', $ins_cmt['msg']);
                    }

                    if ($continous == true) {

                        $ins_cmt['sid'] = $zenmarket_data['sid'];
                        $ins_cmt['ip'] = client_ip();

                        $model->insert_comment($ins_cmt);
                    }
                }
            }
        }

        $limit = 5;
        /**
         * num_comment hook *
         */
        $limit = $this->hook->loader('num_comment', $limit);
        $p->setLimit($limit);
        $p->SetGetPage('cmtPage');
        $start = $p->getStart();
        $sql_limit = $start.','.$limit;

        $zenmarket_data['comments'] = $model->get_comments($zenmarket_data['sid'], $sql_limit);

        foreach ($zenmarket_data['comments'] as $_cmt_k => $_cmt) {

            $_cmt['msg'] = $bbcode->parse($_cmt['msg']);

            $_cmt['msg'] = scan_smiles($_cmt['msg']);
            /**
             * out_msg_comment_content hook *
             */
            $_cmt['msg'] = $this->hook->loader('out_msg_comment_content', $_cmt['msg']);

            $zenmarket_data['comments'][$_cmt_k]['msg'] = $_cmt['msg'];
        }

        $p->setTotal($model->total_result);

        $data['comments_pagination'] = $p->navi_page('?cmtPage={cmtPage}#comments');

        $data['token_comment'] = $security->get_token('token_comment');

        $captcha_security_key = $security->get_token('captcha_security_key', 4);
        $data['captcha_src'] = _HOME . '/captcha/image/image_' . $captcha_security_key . '.jpg';
        // end comments


        // start like and dislike
        if (isset($_GET['_t_'])) {

            if ($security->check_token('_t_', 'GET')) {

                if (isset ($this->user['id']) && !empty($this->user['id'])) {

                    $ldata['fromid'] = $this->user['id'];

                } else {

                    $ldata['ip'] = client_ip();
                }

                $ldata['toid'] = $zenmarket_data['sid'];

                if (isset($_GET['_like_'])) {

                    $model->do_like($ldata);

                } else {

                    if (isset($_GET['_dislike_'])) {

                        $model->do_dislike($ldata);
                    }
                }
                redirect($zenmarket_data['full_url']);
            }
        }
        // end like and dislike

        /**
         * like & dislike
         */
        $zenmarket_data['likes'] = $model->get_like($zenmarket_data['sid']);
        $zenmarket_data['dislikes'] = $model->get_dislike($zenmarket_data['sid']);

        /**
         * num_likes hook *
         */
        $zenmarket_data['likes'] = $this->hook->loader('num_likes', $zenmarket_data['likes']);

        /**
         * num_dislikes hook *
         */
        $zenmarket_data['dislikes'] = $this->hook->loader('num_dislikes', $zenmarket_data['dislikes']);

        $zenmarket_data['is_liked'] = $model->is_liked($zenmarket_data['sid']);
        $zenmarket_data['is_disliked'] = $model->is_disliked($zenmarket_data['sid']);

        /**
         * get like token
         */
        $token_like = $security->get_token('_t_');

        /**
         * set link like & dislike
         */
        $link_like = '<a href="' . $zenmarket_data['full_url'] . '?_like_&_t_=' . $token_like . '" title="Like">' . icon('like') . '</a>';
        $link_dislike = '<a href="' . $zenmarket_data['full_url'] . '?_dislike_&_t_=' . $token_like . '" title="Dislike">' . icon('dislike') . '</a>';

        if ($zenmarket_data['is_liked']) {

            $link_like = icon('like');
        }
        if ($zenmarket_data['is_disliked']) {

            $link_dislike = icon('dislike');
        }

        /**
         * hook link like, dislike
         */
        $zenmarket_data['link_like'] = $this->hook->loader('link_like', $link_like);
        $zenmarket_data['link_dislike'] = $this->hook->loader('link_dislike', $link_dislike);

        /**
         * get link and file download
         */
        $links = $model->get_links($zenmarket_data['sid']);
        $files = $model->get_files($zenmarket_data['sid']);

        /**
         * links_download hook & files_download hook*
         */
        $zenmarket_data['downloads']['links'] = $this->hook->loader('links_download', $links);
        $zenmarket_data['downloads']['files'] = $this->hook->loader('files_download', $files);

        if (empty($zenmarket_data['downloads']['links']) && empty($zenmarket_data['downloads']['files'])) {

            $zenmarket_data['downloads'] = array();

        }

        $data['zenmarket'] = $zenmarket_data;

        if (count($data['zenmarket']) && empty($data['zenmarket']['type_view'])) {

            $data['zenmarket']['type_view'] = 'default';

            /**
             * set_default_view hook *
             */
            $data['zenmarket']['type_view'] = $this->hook->loader('set_default_view', $data['zenmarket']['type_view']);
        }


        $this->zenmarket = $data['zenmarket'];

        $tree[] = url(_HOME, icon('home'), 'title="' . get_config('title') . '"');
        /**
         * first_zenmarket_path hook *
         */
        $tree = $this->hook->loader('first_zenmarket_path', $tree);

        /**
         * zenmarket_data hook *
         */
        $data['zenmarket'] = $this->hook->loader('zenmarket_data', $data['zenmarket']);

        $tree = array_merge($tree, $this->zenmarket_path($id));
        $data['display_tree'] = display_tree($tree);

        $data['page_keyword'] = $data['zenmarket']['keyword'];
        $data['page_des'] = $data['zenmarket']['des'];
        $data['page_url'] = $data['zenmarket']['full_url'];

	
        $this->view->data = $data;

        if ($data['zenmarket']['type']) {

            $this->view->show('zenmarket/' . $data['zenmarket']['type']);
            return;
        }

        $this->view->show('zenmarket');
    }

    public function manager($app = array('index'))
    {
        load_apps(__MODULES_PATH . '/zenmarket/apps/manager', $app);
    }

    private function zenmarket_path($id = 0, $from_recycle_bin = false)
    {
        static $tree = array();
        static $i;
        $i++;

        $model = $this->model->get('zenmarket');

        if ($from_recycle_bin == true) {

            $model->not_filter_recycle_bin(true);

        }

        $zenmarket = $model->get_zenmarket_data($id);

        if (!empty($zenmarket)) {

            if ($i != 1) {

                $tree[] = url($zenmarket['full_url'], $zenmarket['name'], 'title="' . $zenmarket['title'] . '"');
            }

            $parent = $zenmarket['parent'];

            $this->zenmarket_path($parent);

        }

        asort($tree);

        return $tree;
    }



}
