<?php
/**
 * ZenCMS Software
 * Author: ZenThang
 * Email: thangangle@yahoo.com
 * Website: http://zencms.vn or http://zenthang.com
 * License: http://zencms.vn/license or read more license.txt
 * Copyright: (C) 2012 - 2013 ZenCMS
 * All Rights Reserved.
 */
if (!defined('__ZEN_KEY_ACCESS')) exit('No direct script access allowed');

class zenmarketHook extends ZenHook
{

    /**
     *
     * @param array $data
     * @return array
     */
    function lists_in_folder($data)
    {
        /**
         * get zenmarket model
         */
        $model = $this->model->get('zenmarket');
        /**
         * load pagination library
         */
        $p = load_library('pagination');
        /**
         * get hook zenmarket
         */
        $this->get('zenmarket');
        /**
         * start pagination
         */
        $limit = 10;
        /**
         * num_post_display_in_folder hook *
         */
        $limit = $this->loader('num_post_display_in_folder', $limit);

        $p->setLimit($limit);
        $p->SetGetPage('page');
        $start = $p->getStart();
        $sql_limit = $start.','.$limit;

        $data['posts'] = $model->get_list_zenmarket($data['sid'], 'post', array('weight' => 'ASC', 'time' => 'DESC'), $sql_limit);

        $total = $model->total_result;
        $p->setTotal($total);
        $data['posts_pagination'] = $p->navi_page();


        $data['folders'] = $model->get_list_zenmarket($data['sid'], 'folder', array('weight' => 'ASC', 'time' => 'DESC'));

        $data['same_cats'] = $model->get_list_zenmarket($data['parent'], 'folder', array('time' => 'DESC'), 5);

        $limit_rand = 10;
        /**
         * num_rand_post_display_in_folder hook *
         */
        $limit_rand = $this->loader('num_rand_post_display_in_folder', $limit_rand);

        $data['rand_posts'] = $model->get_list_zenmarket(null, 'post', array('RAND()' => ''), $limit_rand);

        return $data;
    }

    /**
     *
     * @param array $data
     * @return array
     */
    function lists_in_post($data)
    {
        $model = $this->model->get('zenmarket');

        $data['other_cats'] = $model->get_list_zenmarket(null, 'folder', array('time' => 'DESC'), 5);

        $data['same_posts'] = $model->get_list_zenmarket($data['parent'], 'post', array('time' => 'DESC'), 5);

        return $data;
    }

    /**
     *
     * @param array $data
     * @return array
     */
    function lists_in_index($data)
    {
        $model = $this->model->get('zenmarket');
        $model->what_gets('url, name, title, time, view, icon');
        $data['new_posts'] = $model->get_list_zenmarket(null, 'post', array('time' => 'DESC'), 10);
        $data['hot_posts'] = $model->get_list_zenmarket(null, 'post', array('view' => 'DESC'), 5);
        $data['rand_posts'] = $model->get_list_zenmarket(null, 'post', array('RAND()' => ''));
        return $data;
    }

    /**
     *
     * @param array $data
     * @return array
     */
    function lists_in_other($data)
    {
        $model = $this->model->get('zenmarket');

        $data['rand_posts'] = $model->get_list_zenmarket(null, 'post', array('RAND()' => ''));

        return $data;
    }

    /**
     * @param $sid
     * @return mixed
     */
    function post_manager_bar($sid) {

        $arr[_HOME . '/zenmarket/manager/editpost/' . $sid . '/step3'] = 'Sửa';
        $arr[_HOME . '/zenmarket/manager/links/' . $sid . '/step2'] = 'Links';
        $arr[_HOME . '/zenmarket/manager/files/' . $sid . '/step2'] = 'Files';
        $arr[_HOME . '/zenmarket/manager/images/' . $sid . '/step2'] = 'Hình ảnh';
        $arr[_HOME . '/zenmarket/manager/delete/' . $sid . '/step2'] = 'Xóa';
        $arr[_HOME . '/zenmarket/manager'] = 'Đến trang quản lí';

        return $arr;
    }

    /**
     * @param $sid
     * @return mixed
     */
    function folder_manager_bar($sid) {

        $arr[_HOME . '/zenmarket/manager/newpost/'.$sid.'/step2'] = 'Viết bài';

        $arr[_HOME . '/zenmarket/manager/cpanel/'.$sid] = 'Đến trang quản lí và cài đặt';

        return $arr;
    }

    /**
     *
     * @param array $tags
     * @return array
     */
    function add_tags($tags)
    {
        foreach ($tags as $keytag => $tag) {
            $tag = trim($tag);

            if (strlen($tag) < 1) {

                unset($tags[$keytag]);
            }
        }
        return $tags;
    }

    /**
     *
     * @param string $data
     * @return string
     */
    function out_content($content)
    {
        return $content;
    }

    /**
     *
     * @param string $data
     * @return string
     */
    function out_bbcode_content($content)
    {
        return $content;
    }

    /**
     *
     * @param string $data
     * @return string
     */
    function out_html_content($content)
    {
        return $content;
    }

    /**
     *
     * @param array $data
     * @return string
     */
    function in_content($content)
    {
        return $content;
    }

    /**
     *
     * @param string $content
     * @return string
     */
    function in_bbcode_content($content)
    {
        $content = br2nl($content);
        return $content;
    }

    /**
     *
     * @param string $content
     * @return string
     */
    function in_html_content($content)
    {
        if (is_mobile()) {
            $content = nl2br($content);
        }
        return $content;
    }

    /**
     * @param $tag
     * @return array
     */
    function out_tag($tag) {
        return $tag;
    }

    function valid_name($name)
    {
        $len = strlen($name);
        if ($len < 3) {
            return false;
        } else {
            return $name;
        }
    }

    public function valid_title($title)
    {
        return $title;
    }

    public function valid_keyword($keyword)
    {
        return $keyword;
    }

    public function valid_des($des)
    {
        return $des;
    }

    public function jar_editor($file) {

        $java = load_library('JavaEditor');

        $model = $this->model->get('zenmarket');

        if (isset($_POST['sub_copyright']) || isset($_POST['sub_copyright_ticked'])) {

            $java->loader($file['full_path']);

            if(!$java->edit_mf()){

                $process['notices'][] = 'Xin lỗi. Hệ thống không thể chỉnh sửa file này';
            } else {

                $updateStt['status'] = $file['status'];
                $updateStt['status']['copyright'] = 1;

                $model->update_file($file['id'], $updateStt);

                $process['success'] = 'Gắn bản quyền vào file <b>MANIFEST.MF</b> thành công!';
            }
        }

        if (isset($_POST['sub_crack']) || isset($_POST['sub_crack_ticked'])) {

            $java->loader($file['full_path']);

            if(!$java->crack()){

                $process['notices'][] = 'Xin lỗi. Hệ thống không thể chỉnh sửa file này';
            } else {

                if(!$java->sms_exist()) {

                    $updateStt['status'] = $file['status'];
                    $updateStt['status']['crack'] = 1;

                    $model->update_file($file['id'], $updateStt);

                    $process['success'] = 'File này không chứa thanh toán sms!';

                } else {
                    $updateStt['status'] = $file['status'];
                    $updateStt['status']['crack'] = 1;

                    $model->update_file($file['id'], $updateStt);

                    $process['success'] = 'Crack thành công!';
                }
            }
        }

        if (isset($_POST['sub_bookmark']) || isset($_POST['sub_bookmark_ticked'])) {

            $java->loader($file['full_path']);

            if(!$java->setBookmark()){

                $process['notices'][] = 'Xin lỗi. Hệ thống không thể chỉnh sửa file này';
            } else {

                $updateStt['status'] = $file['status'];
                $updateStt['status']['bookmark'] = 1;

                $model->update_file($file['id'], $updateStt);

                $process['success'] = 'Gắn bookmark thành công!';
            }
        }

        $file = $model->get_file_data($file['id']);

        if(isset($file['status']['copyright']) && $file['status']['copyright'] ) {
            $copyright = 'copyright_ticked';
            $copyright_title = 'Click để gắn lại bản quyền file MANIFEST.MF';
        } else {
            $copyright = 'copyright';
            $copyright_title = 'Gắn bản quyền file MANIFEST.MF';
        }
        if(isset($file['status']['crack']) && $file['status']['crack'] ) {
            $crack = 'crack_ticked';
            $crack_title = 'Click để crack lại';
        } else {
            $crack = 'crack';
            $crack_title = 'Click file này';
        }
        if(isset($file['status']['bookmark']) && $file['status']['bookmark'] ) {
            $bookmark = 'bookmark_ticked';
            $bookmark_title = 'Click để gắn bookmark lại';
        } else {
            $bookmark = 'bookmark';
            $bookmark_title = 'Gắn bookmark';
        }

        $file['actions_editor'] = array($copyright => $copyright_title, $crack => $crack_title, $bookmark => $bookmark_title);
        if(isset($process)) $file['process']  = $process;
        return $file;
    }


    public function watermark_image($data)
    {
        /*
          $ieditor = load_library('ImageEditor');
          $load = $ieditor->load($data['full_path']);
          if ($load) {
          $wm = array('string' => get_config('string_watermark'),
          'font' => get_config('font_watermark'),
          'fontsize' => 10,
          'rotation' => 0,
          'color' => get_config('color_string_watermark'),
          'background' => get_config('background_watermark'),
          'opacity' => get_config('opacity_watermark'),
          'quality' => 90);
          $ieditor->text_watermark($wm);
          $result = $ieditor->text_watermark_create($data['full_path'], __SITE_PATH.'/files/img/'.$data['file_name']);
          if($result != false) {
          var_dump($result);
          }
          }
         * 
         */
        /**
         * load library
         */
        $wm = load_library('watermark');

        $wm->load_src($data['full_path']);

        $wm->load_wm(__FILES_PATH . '/images/logo_watermark/'.get_config('logo_watermark'));


        if ($wm->do_watermark()) {

            $wm->save($data['full_path']);

        }
        return $data;
    }

    function recycleBin_manager_bar($sid) {

        $act[] = url(_HOME . '/zenmarket/manager/recycleBin?rezenmarket='.$sid, 'Khôi phục', cfm('Bạn chắc chắn khôi bài này?'));
        $act[] = url(_HOME . '/zenmarket/manager/recycleBin?move='.$sid, 'Di chuyển');
        $act[] = url(_HOME . '/zenmarket/manager/recycleBin?delete='.$sid, 'Xóa', cfm('Bạn chắc chắn xóa bài này?'));

        return $act;
    }
}