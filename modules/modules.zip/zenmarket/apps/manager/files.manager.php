<?php
/**
 * name = Quản lí files
 * icon = zenmarket_manager_files
 * position = 100
 */
/**
 * ZenCMS Software
 * Author: ZenThang
 * Email: thangangle@yahoo.com
 * Website: http://zencms.vn or http://zenthang.com
 * License: http://zencms.vn/license or read more license.txt
 * Copyright: (C) 2012 - 2013 ZenCMS
 * All Rights Reserved.
 */
if (!defined('__ZEN_KEY_ACCESS')) exit('No direct script access allowed');

/**
 * get zenmarket model
 */
$model = $obj->model->get('zenmarket');

/**
 * load user data
 */
$user = $obj->user;

/**
 * get hook
 */
$obj->hook->get('zenmarket');

/**
 * load helpers
 */
load_helper('gadget');
load_helper('time');
load_helper('user');
load_helper('zenmarket_access_app');

/**
 * load library
 */
$seo = load_library('seo');
$upload = load_library('upload');
$security = load_library('security');
$ZenMarketValid = load_library('ZenMarketValid');
$parse = load_library('parse');
$permission = load_library('permission');
$permission->set_user($obj->user);
$java = load_library('JavaEditor');

/**
 * check access
 */
if (is_allow_access_zenmarket_app(__FILE__) == false) {
    show_error(403);
}

/**
 * set page title
 */
$page_title = 'Quản lí files';
$tree[] = url(_HOME . '/zenmarket/manager', 'Store manager');
$tree[] = url(_HOME . '/zenmarket/manager/files', $page_title);
$data['display_tree'] = display_tree_modulescp($tree);
$data['page_title'] = $page_title;

$sid = 0;
$step = '';
$act = '';
$act_id = 0;

if (isset($app[1])) {
    $sid = $security->removeSQLI($app[1]);
    $sid = (int)$sid;
}
if (isset($app[2])) {
    $step = $security->cleanXSS($app[2]);
}
if (isset($app[3])) {
    $act = $security->cleanXSS($app[3]);
}
if (isset($app[4])) {
    $act_id = $security->removeSQLI($app[4]);
    $act_id = (int)$act_id;
}

switch ($step) {
    default:

        if (empty($sid) or $model->zenmarket_exists($sid) == false) {

            if (isset($_POST['sub_step1'])) {

                if (isset($_POST['uri'])) {

                    if (!is_numeric($_POST['uri'])) {

                        $cid = $ZenMarketValid->preg_match_url($_POST['uri']);

                        $cid = (int)$cid;
                    } else {
                        $cid = $security->removeSQLI($_POST['uri']);
                    }
                    if (!empty($cid)) {

                        if ($model->zenmarket_exists($cid) == false) {

                            $data['notices'] = 'Không tồn tại mục này';
                        } else {
                            $zenmarket = $model->get_zenmarket_data($cid, 'type');

                            if ($zenmarket['type'] != 'post') {

                                $data['notices'] = 'Bạn chỉ có thể thêm file vào bài viết';
                            } else {

                                redirect(_HOME . '/zenmarket/manager/files/' . $cid . '/step2');
                            }
                        }
                    } else {
                        $data['notices'] = 'Không tồn tại chuyên mục này';
                    }
                }
            }
            $obj->view->data = $data;
            $obj->view->show('zenmarket/manager/files/step1');
            return;
        } else {

            redirect(_HOME . '/zenmarket/manager/files/' . $sid . '/step2');
        }
        break;

    case 'step2':

        if (empty($sid) or $model->zenmarket_exists($sid) == false) {
            redirect(_HOME . '/zenmarket/manager/files');
        }

        $zenmarket = $model->get_zenmarket_data($sid);
        $zenmarket['stat']['num_files'] = $model->count_files($sid);
        $zenmarket['stat']['num_links'] = $model->count_links($sid);

        switch ($act) {

            default:

                $files = $model->get_files($sid);
                $data['zenmarket'] = $zenmarket;
                $data['zenmarket']['files'] = $files;
                $data['java'] = $java;
                $obj->view->data = $data;
                $obj->view->show('zenmarket/manager/files/step2');
                break;

            case 'add':

                $data['form_files'] = array();

                $extension_allow_upload = 'jar|jad|apk|ipa|zip|rar|tar|gz|sql|jpg|jpeg|png|gif|bmp';
                /**
                 * extension_allow_upload hook *
                 */
                $extension_allow_upload = $obj->hook->loader('extension_allow_upload', $extension_allow_upload);

                $num_up = 5;
                /**
                 * number_file_per_upload hook *
                 */
                $num_up = $obj->hook->loader('number_file_per_upload', $num_up);

                for ($i = 1; $i <= $num_up; $i++) {

                    $data['form_files'][] = $i;
                }

                if (isset($_POST['sub_add'])) {

                    if (!$security->check_token('token_add_file')) {

                        redirect(_HOME . '/zenmarket/manager/files/' . $sid . '/step2');

                    } else {

                        $num_has = 0;

                        for ($i = 1; $i <= $num_up; $i++) {

                            $num_has++;

                            if (isset($_GET['remote'])) {

                                $check_what = $_POST['link' . $i];
                                $get = 'link' . $i;

                            } else {
                                $check_what = $_FILES['file' . $i]['tmp_name'];
                                $get = 'file' . $i;
                            }

                            if (empty($check_what)) {

                                $num_has--;

                            } else {

                                if (isset($_POST['name' . $i]) && strlen($_POST['name' . $i])) {

                                    $upload->set_file_name($_POST['name' . $i]);
                                }

                                $dir = __FILES_PATH . '/posts/files_upload';

                                $subdir = auto_mkdir($dir);

                                $upload->upload_path = $dir . '/' . $subdir;

                                $upload->allowed_types = $extension_allow_upload;

                                if (!$upload->do_upload($get)) {

                                    $error[] = $upload->error;

                                } else {

                                    $dataup = $upload->data();

                                    $InsertData['url'] = $subdir . '/' . $dataup['file_name'];
                                    $InsertData['uid'] = $obj->user['id'];
                                    $InsertData['sid'] = $sid;
                                    $InsertData['size'] = $dataup['file_size'];
                                    $InsertData['type'] = get_ext($dataup['file_name']);

                                    if (isset($_POST['name' . $i]) && strlen($_POST['name' . $i])) {

                                        $InsertData['name'] = h($_POST['name' . $i]);
                                    } else {

                                        $InsertData['name'] = h($dataup['file_name']);
                                    }

                                    if (!$model->insert_file($InsertData)) {

                                        @unlink($dir . '/' . $InsertData['url']);

                                        $error[] = array(
                                            'Không thể ghi dữ liệu'
                                        );
                                    }
                                }
                            }
                        }

                        if (!isset($error)) {

                            redirect(_HOME . '/zenmarket/manager/files/' . $sid . '/step2');
                        } else {

                            if (count($error) == $num_has) {

                                $data['errors'] = $upload->error;
                            } else {
                                $data['notices'][] = 'Một vài file không thể tải lên';
                            }
                        }
                    }
                }

                $data['files_allowed'] = $extension_allow_upload;
                $data['token'] = $security->get_token('token_add_file');
                $data['zenmarket'] = $zenmarket;
                $obj->view->data = $data;

                if (isset($_GET['remote'])) {

                    $obj->view->show('zenmarket/manager/files/add_file_remote');
                } else {
                    $obj->view->show('zenmarket/manager/files/add_file');
                }
                break;

            /**
             * edit file
             */
            case 'edit':

                if (empty($act_id)) {

                    redirect(_HOME . '/zenmarket/manager/files/' . $sid . '/step2');
                }

                $file = $model->get_file_data($act_id);

                if (empty($file)) {

                    redirect(_HOME . '/zenmarket/manager/files/' . $sid . '/step2');
                }

                if (isset($_POST['sub_edit'])) {

                    /**
                     * check if is lower levels of user file then blocked
                     */
                    if ($permission->is_lower_levels_of($file['uid'])) {

                        $data['errors'][] = 'Bạn không có quyền sửa file của cấp trên';

                    } else {

                        if (!$security->check_token('token_edit_file')) {

                            redirect(_HOME . '/zenmarket/manager/files/' . $sid . '/step2');

                        } else {

                            $rename = true;

                            if (empty($_POST['name']) or $_POST['name'] == $file['name']) {

                                $name = end(explode('/', $file['url']));

                            } else {

                                $dir = __SITE_PATH . '/files/posts/files_upload';

                                $new_name = $seo->url($_POST['name']);

                                $new_name = $new_name . '-' . time() . '.' . get_ext($file['url']);

                                $new_url = get_time_dir($file['url']) . '/' . $new_name;

                                $old_file = $dir . '/' . $file['url'];

                                $new_file = $dir . '/' . $new_url;

                                $rename = @rename($old_file, $new_file);
                            }

                            if (isset($name)) {

                                $update['name'] = h($name);
                            } else {
                                $update['name'] = h($_POST['name']);
                            }

                            if ($rename) {

                                if (!empty($new_url)) {
                                    $update['url'] = $new_url;
                                }
                                if (!empty($new_file)) {
                                    $update['size'] = @filesize($new_file);
                                }

                                if (!$model->update_file($act_id, $update)) {

                                    $data['notices'][] = 'Lỗi ghi dữ liệu. Vui lòng thử lại';
                                } else {

                                    redirect(_HOME . '/zenmarket/manager/files/' . $sid . '/step2');
                                }
                            } else {
                                $data['errors'][] = 'Không thể đổi tên file';
                            }
                        }
                    }
                }

                $file['actions_editor'] = array();

                if (!empty($file['type'])) {

                    /**
                     * {type}_editor hook *
                     */
                    $file = $obj->hook->loader($file['type'] . '_editor', $file);

                }

                if (isset($file['process']['success'])) {
                    $data['success'] = $file['process']['success'];
                }
                if (isset($file['process']['notices'])) {
                    $data['notices'] = $file['process']['notices'];
                }
                if (isset($file['process']['success'])) {
                    $data['errors'] = $file['process']['errors'];
                }

                $data['file'] = $file;

                $data['token'] = $security->get_token('token_edit_file');
                $data['zenmarket'] = $zenmarket;

                $obj->view->data = $data;
                $obj->view->show('zenmarket/manager/files/edit_file');
                break;

            case 'delete':

                if (empty($act_id)) {

                    redirect(_HOME . '/zenmarket/manager/files/' . $sid . '/step2');
                }

                /**
                 * get file data
                 */
                $file = $model->get_file_data($act_id);

                if (empty($file)) {

                    redirect(_HOME . '/zenmarket/manager/files/' . $sid . '/step2');
                }

                if (isset($_POST['sub_delete'])) {

                    /**
                     * check access
                     */
                    if ($permission->is_lower_levels_of($file['uid'])) {

                        $data['errors'][] = 'Bạn không có quyền xóa link của cấp trên';
                    } else {

                        if (!$security->check_token('token_delete_file')) {

                            redirect(_HOME . '/zenmarket/manager/files/' . $sid . '/step2');

                        } else {

                            if (!$model->delete_file($act_id)) {

                                $data['notices'][] = 'Không thể xóa file. Vui lòng thử lại';
                            } else {

                                redirect(_HOME . '/zenmarket/manager/files/' . $sid . '/step2');
                            }
                        }
                    }
                }

                $data['token'] = $security->get_token('token_delete_file');
                $data['zenmarket'] = $zenmarket;
                $data['file'] = $file;
                $obj->view->data = $data;
                $obj->view->show('zenmarket/manager/files/delete_file');
                break;
        }
        break;
}
