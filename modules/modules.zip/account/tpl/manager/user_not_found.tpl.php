<?php load_header() ?>

    <h1 class="title border_orange">Quản lí chức vụ</h1>

<?php load_message() ?>

    <div class="detail_content">
        <h2 class="title border_blue">Không có thật</h2>

        <div class="item">
            Thành viên này không có thật
        </div>
    </div>

<?php load_footer() ?>