<?php
/**
 * ZenCMS Software
 * Author: ZenThang
 * Email: thangangle@yahoo.com
 * Website: http://zencms.vn or http://zenthang.com
 * License: http://zencms.vn/license or read more license.txt
 * Copyright: (C) 2012 - 2013 ZenCMS
 * All Rights Reserved.
 */
if (!defined('__ZEN_KEY_ACCESS')) exit('No direct script access allowed');

Class _paging_post_contentController Extends ZenController
{

    function _run() {

        function _paging_post_content_html_by_char($content) {

            $num_char = 1000;

            $p = load_library('paging_post_content');

            $p->setInfo($num_char, $content);

            if (!isset($_GET['page'])){

                $page = 1;

            } else {

                $page = $_GET["page"];
            }

            $out = $p->getStrShow($page);

            if (class_exists('DOMDocument')) {

                $dom = new DOMDocument("1.0", "utf-8");
                $out = mb_convert_encoding($out, 'HTML-ENTITIES', "UTF-8");
                @$dom->loadHTML($out);
                $dom->formatOutput = true;
                $out = $dom->saveHTML();

            } elseif (class_exists('tidy')) {

                // Specify configuration
                $config = array(
                    'indent'         => true,
                    'output-xhtml'   => true,
                    'wrap'           => 200);

                $tidy = new tidy;
                $out = mb_convert_encoding($out, 'HTML-ENTITIES', "UTF-8");
                $tidy->parseString($out, $config, 'utf8');
                $tidy->cleanRepair();

                $out = $tidy;
            }

            $nav = $p->navi_page('?page=');

            $out = $out . $nav;

            return $out;

        }

        run_hook('blog', 'out_html_content', '_paging_post_content_html_by_char');

        function _paging_post_content_bbcode_by_char($content) {

            $num_char = 1000;

            $p = load_library('paging_post_content');

            $p->setInfo($num_char, $content);

            if (!isset($_GET['page'])){

                $page = 1;

            } else {

                $page = $_GET["page"];
            }

            $out = $p->getStrShow($page);

            $nav = $p->navi_page('?page=');

            $out = $out . $nav;

            return $out;

        }

        run_hook('blog', 'out_bbcode_content', '_paging_post_content_bbcode_by_char');

    }
}