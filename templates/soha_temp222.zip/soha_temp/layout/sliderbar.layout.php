<script type="text/javascript">
    function slider_init(ele, img_width) {
        var num_img_in_slider = ele.children().children().length,
            parentWidth = ele.parent().width(),
            imgs_slide_width = (img_width + 10) * num_img_in_slider;

        if (parentWidth < imgs_slide_width) {
            var firstRun = true;
            var anispeed = 300; // miliseconds.
            var ease = 'swing';
            var sudoSlider = ele.sudoSlider({
                prevNext: true,
                continuous: true,
                autowidth: false,
                autoheight: false,
                clickableAni: false,
                ease: ease,
                speed: anispeed,
                beforeAniFunc: function (t) {
                    var width = $(this).width(),
                    //parentWidth = ele.parent().width(),
                        marginleft,
                        anitime = firstRun ? 0 : anispeed;
                    var availableBanners = Math.floor(parentWidth / width);
                    marginleft = (parentWidth - availableBanners * width + 10) / 2;
                    ele.stop().animate({marginLeft: marginleft}, {duration: anitime, easing: ease});
                    firstRun = false;
                    $('.blackLeft', ele.parent()).stop().animate({width: marginleft - 5}, {duration: anitime, easing: ease});
                    $('.blackRight', ele.parent()).stop().animate({width: marginleft - 15}, {duration: anitime, easing: ease});
                },
                afterAniFunc: function (t) {

                }
            });
            $('.blackRight', ele.parent()).click(function () {
                sudoSlider.goToSlide('next');
            });
            $('.blackLeft', ele.parent()).click(function () {
                sudoSlider.goToSlide('prev');
            });
        }
    }

    $(document).ready(function () {
        slider_init($("#top_slider"), 768);
        slider_init($("#new_apps"), 300);
        slider_init($("#hot_apps"), 300);
        slider_init($("#download_apps"), 300);

        $(window).resize(function () {
            slider_init($("#top_slider"), 768);
            slider_init($("#new_apps"), 300);
            slider_init($("#hot_apps"), 300);
            slider_init($("#download_apps"), 300);
        });
    });
</script>

<div class="slider">
    <!-- Slides -->
    <div class="slider-wrapper top_slider">
        <div class="blackLeft"></div>
        <div class="blackRight"></div>
        <div id="top_slider">
            <ul>

                <li>
                    <div class="introduction int_bg_banner">
                        <h2>ZenCMS - Web developers</h2>

                        <p>
                            ZenCMS là một open - source cung cấp cho bạn một môi trường thiết kế wap, web chuyên nghiệp.

                            Với ZenCMS bạn có thể tạo cho mình một trang blog tải game, blog đọc truyện hay một website
                            cá nhân hoặc một trang web bất kì.
                            Không gì là không thể với ZenCMS
                        </p>
                    </div>
                </li>
                <li>
                    <div class="introduction int_bg_white">

                        <table style="width: 100%;">
                            <tr>
                                <td width="30%"><?php echo icon('zenbox') ?></td>
                                <td style="padding-left: 30px; vertical-align: top;">
                                    <h2>Tính năng</h2>

                                    <p>ZenCMS sử dụng mô hình MVC kết hợp cơ chế load module và template tạo nên tính
                                        linh động, khả năng tùy biến cao</p>
                                    <table style="width: 100%;">
                                        <tr>
                                            <td width="50%" style="padding-left: 25px;">
                                                <ul>
                                                    <li>MVC pattern</li>
                                                    <li>Modules</li>
                                                    <li>Templates</li>
                                                </ul>
                                            </td>
                                            <td width="50%">
                                                <ul>
                                                    <li>Cache</li>
                                                    <li>Hook</li>
                                                    <li>"Mini Framework"</li>
                                                </ul>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </div>
                </li>
                <li>
                    <div class="introduction int_bg_gray">
                        <h2>Những ai đang sử dụng ZenCMS</h2>
                        <p>
                            Rất nhiều Webmaster đang sử dụng ZenCMS để bắt đầu sự nghiệp của mình. <br/>
                            Bởi vì ZenCMS không chỉ thân thông minh, thân thiện, đa tính năng mà hơn nữa ZenCMS hoàn toàn do 100% tay người Việt thực hiện
                        </p>
                    </div>
                </li>

            </ul>
        </div>
    </div>
</div>