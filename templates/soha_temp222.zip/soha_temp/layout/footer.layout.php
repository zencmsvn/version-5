</div>

<div class="clear-fix">
    <div class="pull-left sidebar list_cats">
    </div>
    <div class="mainContent">
        <div class="mainContentWrapper">
            <div id="footer" class="contentContainer">
                <div class="menu clear-fix">
                    <a href="<?php echo _HOME ?>">Trang ch?</a>
                    <a href="http://forum.zencms.vn">Di?n ?àn</a>
                    <a rel="nofollow" href="<?php echo _HOME ?>/introduction">H??ng d?n s? d?ng</a>
                    <a href="<?php echo _HOME ?>/contact" rel="nofollow">Liên h?</a>
                    <a rel="nofollow" href="<?php echo _HOME ?>/api" rel="nofollow">Nhà phát tri?n</a>
                </div>
                <div class="clear-fix">
                    <div class="contentwrapper">
                        <div class="contentcolumn">
                            <div class="add-foot">
                                <p><b>ZenCMS - Web developers</b></p>

                                <p>Hotline: 01686298448</p>

                                <p>Email: <a href="mailto:thangangle@yahoo.com">thangangle@yahoo.com</a></p>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    /*<![CDATA[*/
    jQuery(function($) {
        jQuery('body').tooltip({'selector':'a[rel=tooltip]'});
        jQuery('body').popover({'selector':'a[rel=popover]'});
    });
    /*]]>*/
</script>
</body>
</html>