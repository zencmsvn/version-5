<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="language" content="en"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="<?php echo _BASE_TEMPLATE ?>/theme/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo _BASE_TEMPLATE ?>/theme/bootstrap-responsive.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo _BASE_TEMPLATE ?>/theme/yii.css" />
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo _BASE_TEMPLATE ?>/js/bootstrap.min.js"></script>
    <title><?php echo $page_title ?></title>
    <meta name="keywords" content="<?php echo $page_keyword ?>"/>
    <meta name="description" content="<?php echo $page_des ?>"/>
    <link rel="canonical" href="<?php echo $page_url ?>"/>
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,500' rel='stylesheet' type='text/css'>

    <link href="<?php echo _BASE_TEMPLATE ?>/theme/styles.css" rel="stylesheet" media="screen">

    <script type="text/javascript">
        var baseUrl = "<?php echo _HOME ?>";
        var user_id = "";
    </script>
    <script type="text/javascript" src="<?php echo _BASE_TEMPLATE ?>/js/jquery.mCustomScrollbar.js"></script>
    <script type="text/javascript" src="<?php echo _BASE_TEMPLATE ?>/js/jquery.sudoSlider.js"></script>
    <script type="text/javascript" src="<?php echo _BASE_TEMPLATE ?>/js/jquery.dialog2.js"></script>
    <script type="text/javascript" src="<?php echo _BASE_TEMPLATE ?>/js/jquery.form.js"></script>
    <script type="text/javascript" src="<?php echo _BASE_TEMPLATE ?>/js/jquery.validate.js"></script>
    <script type="text/javascript" src="<?php echo _BASE_TEMPLATE ?>/js/jquery.autocomplete.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo _BASE_TEMPLATE ?>/theme/jquery.autocomplete.css"/>
    <!-- modalbox -->
    <script type="text/javascript" src="<?php echo _BASE_TEMPLATE ?>/js/modalbox/modal.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo _BASE_TEMPLATE ?>/js/modalbox/modal.css"/>
    <script type="text/javascript" src="<?php echo _BASE_TEMPLATE ?>/js/modalbox/client.js"></script>

    <script type="text/javascript" src="<?php echo _BASE_TEMPLATE ?>/js/script.js"></script>

    <link rel="icon" type="image/x-icon" href="<?php echo_BASE_TEMPLATE ?>/images/favicon.ico"/>

<?php foreach ($page_more as $more): ?>
        <?php echo $more ?>
    <?php endforeach ?>

    <!--[if gte IE 9]>
    <style type="text/css">
        .gradient {
            filter: none;
        }
    </style>
    <![endif]-->

</head>
<body>

<div id="header">
    <div id="pageNav" class="pull-left">
        <div class="pageNavWrapper">
            <div id="search_box" class="pull-left">
                <form action="<?php echo _HOME ?>/search" method="get" class="form-search">
                    <div class="search-wrapper">
                        <i class="icon-search"></i>
                        <input type="text" id="inputSearch" name="keyword" class="input-medium search-query" placeholder="Tìm ki?m" autocomplete="off">
                    </div>
                </form>
            </div>
            <div id="userNav" class="pull-right">
                <div class="btn-group">
                    <a href="javascript:void(0)" rel="nofollow"
                       onclick="openMyModal('<?php echo _HOME ?>/login',500,400);"
                       id="bt_login_vietid" class="ming_id">
                        <button class="btn btn-inverse">
                            ??ng nh?p
                        </button>
                    </a>
                    <a href="javascript:void(0)" rel="nofollow"
                       onclick="openMyModal('<?php echo _HOME ?>/register',500,450);"
                       class="ming_id">
                        <button class="btn btn-inverse mleft10">
                            ??ng kí
                        </button>
                    </a>
                </div>
            </div>

            <div class="user-info" style="display: none">
                <div class="user-info-wrapper">
                    <div class="user-info-header">
                        <span class="close"></span>

                        <div class="title">
                            <span>Tài kho?n</span>
                            <a href="#" id="link-buy-scoin"><span class="nap_scoin"></span></a>
                        </div>
                    </div>
                    <div class="user-info-container">
                        <div class="navigationBar">
                            <div class="device_types">
                                <div class="buttons" id="get-info">
                                    <button class="active" data-href="http://sohastore.vn/user/getinfo.html">
                                        Thông tin cá nhân
                                    </button>
                                    <button data-href="http://sohastore.vn/user/gethistory.html">
                                    	L?ch s? giao d?ch
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="user-info-content">
                        </div>
                    </div>
                </div>
                <div class="modal-backdrop"></div>
            </div>
        </div>
    </div>
    <div id="pageLogo" class="pull-left">
        <a href="<?php echo _HOME ?>">
            <h1 class="logo">ZenCMS</h1>
        </a>
    </div>
</div>
<div class="wrapper">