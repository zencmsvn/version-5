<div class="banners">
    <div class="slider-wrapper">
        <div class="blackLeft"></div>
        <div class="blackRight"></div>
        <div class="banner_slider" id="new_apps">
            <ul>
                <li>
                    <a href="http://sohastore.vn/tinh-kiem-323.html">
                        <img src="http://sohastore.vcmedia.vn/thumb_w/300/1945/13052013/1368416477450x150.jpg"/>
                    </a>
                </li>
                <li>
                    <a href="http://sohastore.vn/doc-tin-pega-55.html">
                        <img src="http://sohastore.vcmedia.vn/thumb_w/300/2502/08042013/1365412558pega 450x150.jpg"/>
                    </a>
                </li>
                <li>
                    <a href="http://sohastore.vn/iga-587.html">
                        <img src="http://sohastore.vcmedia.vn/thumb_w/300/1945/08042013/1365408882450x150_IgA.jpg"/>
                    </a>
                </li>
                <li>
                    <a href="http://sohastore.vn/sohaphim-151.html">
                        <img src="http://sohastore.vcmedia.vn/thumb_w/300/1945/08042013/1365410312soha phim 450x150.jpg"/>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>