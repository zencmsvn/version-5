(function ($) {
    $(window).load(function () {
        var api = "http://vietid.net/login/checksession";
        $.ajax({
            url: api,
            dataType: 'jsonp',
            jsonpCallback: 'mingAuthCallBack',
            success: function (xhr) {
                if (xhr == 'null' && user_id == 0) {
                    return false;
                }

                $.ajax({
                    data: { "data": xhr, 'url': window.location.href },
                    error: function () {
                        //alert("Có lỗi xảy ra!!!");
                    },
                    success: function (data) {
                        if (data.reload == 1) {
                            $('#userNav .btn-group').html(data.html);
                        }
                    },
                    dataType: 'json',
                    type: "POST",
                    url: baseUrl + '/home/checksession/'
                });
                //TODO: Lấy dữ liệu cho vào Popup thông tin cá nhân
                return false;
            }
        });
        $("#user-info").on("click", function () {
            $.ajax({
                dataType: 'html',
                url: baseUrl + '/user/getinfo',
                success: function (html) {
                    $(".user-info-content").html(html);
                }
            });
            $(".user-info").show();
            $("body").addClass('oh');
        });
        
        $("#link-buy-scoin").on('click', function(e) {
        	e.preventDefault();
            $.ajax({
            	data: {'returnurl': window.location.href},
                dataType: 'json',
                url: baseUrl + '/user/buyScoin',
                success: function (html) {
                	if(html) {
                		window.location.href = html;
                	}
                }
            });
        });

        $("button", ".user-info #get-info").on("click", function(e){
            e.preventDefault();
            $("button", ".user-info #get-info").removeClass('active');
            $(this).addClass('active');
            $.ajax({
                dataType: 'html',
                url: $(this).attr("data-href"),
                success: function (html) {
                    $(".user-info-content").html(html);
                }
            });
        });
        $(".close", ".user-info").on("click", function () {
            $(".user-info").hide();
            $("body").removeClass('oh');
        });
        $(".scrollable").each(function (i) {
            var height;
            height = $(".padlr10", $(this)).children().length * 30;
            if ($(window).height < 768) {
                $(this).css({
                    'height': height,
                    'max-height': '318px'
                });
            } else {
                $(this).css({
                    'height': height,
                    'max-height': '518px'
                });
            }
        });
        $(".scroll_hor").mCustomScrollbar({
            horizontalScroll: true
        });
        $(".scrollable").mCustomScrollbar({
        });
        function bindScroll() {
            $(".scrollable").each(function (i) {
                var height;
                height = $(".padlr10", $(this)).children().length * 30;
                if ($(window).height < 768) {
                    $(this).css({
                        'height': height,
                        'max-height': '318px'
                    });
                } else {
                    $(this).css({
                        'height': height,
                        'max-height': '518px'
                    });
                }
            });

            $('.scrollable').bind('jsp-scroll-y',function (event, scrollPositionY, isAtTop, isAtBottom) {
                var parent = $(this).parent();
                if (isAtTop) {
                    parent.children('.hr').hide();
                    parent.children('.hr_top').show();
                    parent.children('.top_shadow').hide();
                    parent.children('.bottom_shadow').show();
                } else if (isAtBottom) {
                    parent.children('.hr').hide();
                    parent.children('.hr_bottom').show();
                    parent.children('.bottom_shadow').hide();
                    parent.children('.top_shadow').show();
                } else {
                    parent.children('.hr').hide();
                    parent.children('.bottom_shadow').show();
                    parent.children('.top_shadow').show();
                }
            }).jScrollPane();
        }


        function bindHoriScroll() {
            $('.scroll_hor').bind('jsp-scroll-x',function (event, scrollPositionX, isAtLeft, isAtRight) {
                if (scrollPositionX) {
                    $(".mask.left", $(this).parent()).show();
                    $(".mask.right", $(this).parent()).show();
                }
                if (isAtRight) {
                    $(".mask.right", $(this).parent()).hide();
                } else if (isAtLeft) {
                    $(".mask.left", $(this).parent()).hide();
                }
            }).jScrollPane();
        }

        // su kien category
        function initSideBar() {
            if (document.body.clientWidth > 979) {
                $('.list_cats').show().addClass('opened');
                $('#left_nav').addClass('opened');
                if ($("#bodyContainer").height() < top_sidebar_height) {
                    $("#bodyContainer").css('height', top_sidebar_height);
                }
            } else {
                $('.list_cats').hide().removeClass('opened');
                $('#left_nav').removeClass('opened');
                $("#bodyContainer").css('height', 'auto');
            }
        }

        $('a', '#detailTab').click(function (e) {
            e.preventDefault();
            $(this).tab('show');
        });
        $("#left_nav, .list_cats").hover(function () {
            if (!$(this).hasClass('opened')) {
                $('.list_cats').show();
                $(".scrollable").mCustomScrollbar("update");
            }
        }, function () {
            if (!$(this).hasClass('opened')) {
                $('.list_cats').hide();
                $(".scrollable").mCustomScrollbar("update");
            }
        });
//        $("#left_nav:not(.opened), .list_cats:not('.opened')").hover(function () {
//            $('.list_cats').show();
//            $(".scrollable").mCustomScrollbar("update");
//        }, function () {
//
//            $('.list_cats').hide();
//            $(".scrollable").mCustomScrollbar("update");
//        });

        var top_sidebar_height = $("#top_sidebar").height() - 40;
        $(window).resize(function () {
            initSideBar();
        });

        $(document).controls();
        initSideBar();
        if ($('.list_cats').is(":visible") && $("#bodyContainer").height() < top_sidebar_height) {
            $("#bodyContainer").css('height', top_sidebar_height);
        }

        $("#inputSearch").autocomplete(baseUrl + '/search/autocomplete/', {
            width: $("#inputSearch").width() + 24,
            matchContains: true,
            selectFirst: false,
            scrollHeight: 300,
            delay: 2
        });

        $("#inputSearch").result(function (input, data, text) {
            window.location = baseUrl + "/tim-kiem/" + data + ".html";
        });
        
        $("#relative").removeClass('active');
    });
})(jQuery);
var App = {
    download: function (data) {
        if (data.type == 1) {
            if (data.show_popup == 1) {
                this.showPaid(data, baseUrl + '/ajax/showPopupPaid/');
            } else {
                this.hideModal();
                _gaq.push(['_trackEvent', 'Ajax_download', 'downloaded', data.message]);
                window.location.href = data.message;
                //window.open(data.message, "_blank");
            }
        } else {
            if (data.show_login == 1) {
                this.hideModal();
                openMyModal(baseUrl + '/home/MingidRequest', 500, 400);

                //window.location.href = data.message;                
            } else {
                var html = '<div style="text-align: center">' +
                    '<div class="iconError"></div>' +
                    '<div style="margin-bottom: 10px;">' + data.message + '</div>';

                if (typeof data.results != 'undefined') {
                	this.showPaid(data, baseUrl + '/ajax/showBuyScoin/');
                } else {
                    html = html + '</div>';
                    $(".modal-body").html(html);
                }
            }
        }
    },
    hideModal: function () {
        removeDialog("tai_ung_dung");
    },
    showPaid: function (data,url) {
        $.ajax({
            data: { "transaction": data },
            error: function () {
                alert("Có lỗi xảy ra!!!");
            },
            success: function (xhr) {
                $(".modal-body").html(xhr);

                $('.close').on('click', function (e) {
                    $.ajax({
                        data: { "transaction": data },
                        error: function () {
                            alert("Có lỗi xảy ra!!!");
                        },
                        success: function (t) {
                        },
                        type: "POST",
                        url: baseUrl + '/ajax/cancelPaid/'
                    });
                    e.preventDefault();
                });
            },
            type: "POST",
            url: url
        });
    }
};
function closeDialog(ele_id) {
    var overlay = $(".modal-backdrop");

    overlay.hide();

    $("#" + ele_id)
        .parent().hide().end()
        .trigger("dialog2.closed")
        .removeClass("opened");
}
function removeDialog(ele_id) {
    $(".modal-backdrop").remove();

    $("#" + ele_id).removeData("dialog2").parent().remove();
}
