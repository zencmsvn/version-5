<div class="post_detail">
    <span class="view text_smaller gray">Bởi <?php echo show_nick($zenmarket['uid'], true) ?>, <?php echo icon('view', 'vertical-align: text-bottom;') ?> <?php echo $zenmarket['view'] ?></span><br/>
    <span class="like"><?php echo $zenmarket['likes'] ?></span> <?php echo $zenmarket['link_like'] ?>
    <?php echo $zenmarket['link_dislike'] ?> <span class="like"><?php echo $zenmarket['dislikes'] ?></span>
</div>