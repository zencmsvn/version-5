<div class="manager_bar">
    <?php foreach ($zenmarket['manager_bar'] as $link => $name): ?>
        <a href="<?php echo $link ?>" class="link_manager"><?php echo $name ?></a>
    <?php endforeach; ?>
</div>