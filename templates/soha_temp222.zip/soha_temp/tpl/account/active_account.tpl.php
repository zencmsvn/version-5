<?php load_header() ?>

    <div class="detail_content">
        <h1 class="title border_blue">Kích hoạt tài khoản</h1>

        <?php load_message() ?>

    </div>

<?php load_footer() ?>