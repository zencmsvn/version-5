<?php load_header() ?>

<div class="mainContent">
<div class="mainContentWrapper">
<div class="navigationBar">

</div>
<div class="contentContainer" id="bodyContainer">


<!--Body content-->
<div id="homeContainer">

<?php load_layout('sliderbar') ?>



    

<div class="app-container">

	

<div class="app-wrapper padding20">
<h3 class="intro_title">ZenCMS có gì hấp dẫn</h3>
<div class="container">

<div class="new_feature_holder">
	<div class="holder">

	<div class="main_feature_item_holder_new">	
		
		<div class="feature_main_title_new">
Với ZenCMS bạn có thể</div>
		
Bạn có ý tưởng và chúng tôi đã chuẩn bị sẵn cho bạn:<br>	
1: Một trang Blog game, Blog truyện, hình ảnh hoặc video trên nền module "Store" - Module chính của ZenCMS<br>
2: Một Forum<br>
3: Một Chatbox<br>

Đó chỉ là những gì đã làm. 
Còn nếu bạn có ý tưởng thì không gì là không thể với ZenCMS

</div>

	<div class="main_feature_item_holder_new">	
		
		<div class="feature_main_title_new">
Quản lí bài viết</div>

Với một bảng điều khiển dễ hiểu, bạn sẽ không phải lo nghĩ đến chuyện làm sao để di chuyển mục này, làm sao để sửa bài viết hay làm sao để viết bài mới.<br>
Bởi vì chúng tôi đã trực quan hóa quá trình quản lí bằng các nút như <b>+ x ↑ ↓ ⇑ ⇓</b> với các chức năng tương ứng: Thêm, xóa, di chuyển ..
Với mỗi bài viết bạn có thể quản lí link, file đính kèm, hình ảnh. <br>
Với sự đơn giản mà ZenCMS đem lại, bạn chỉ cần một vài click là đã có thể kiểm soát hoàn toàn website của mình
</div>
	<div class="clear"></div>

<div class="main_feature_item_holder_new">	
		
		<div class="feature_main_title_new">
Quản lí thành viên		</div>
		
Thành viên là một yếu tố không thể thiếu của một website. <br>
Chính vì thể ZenCMS cho phép các thành viên được tham gia trao đổi trên website<br>
Thành viên muốn tham gia thì phải đăng kí tài khoản. (Có thể xác thực bằng email)<br>
Bạn có nhiều tùy chọn chế độ kích hoạt tài khoản tại bảng điều khiển admin (Admin Cpanel)
Tất cả những gì bạn cần làm là vào Admin Cpanel và kiểm soát thành viên của mình

</div>

<div class="main_feature_item_holder_new">	
		
		<div class="feature_main_title_new">
Tính năng đặc biệt		</div>
		
Như ở các phiên bản trước, ZenCMS vẫn tiếp tục giúp bạn: <br>
- Tự động lấy lấy toàn bộ ảnh trong bài viết về host (Tùy chọn)<br>
- Tự động đóng dấu ảnh (Tùy chọn)<br>
- Chèn bản quyền vào java (Tùy chọn)<br>
- Crack java (Tùy chọn)<br>
- Chèn bookmark vào java(Tùy chọn)<br>
Đó là những tiện ích hàng đầu hiện nay
</div>
<div class="clear"></div>
	<div class="main_feature_item_holder_new">	
		
		<div class="feature_main_title_new">
Tính năng chia sẻ		</div>
		
Bạn là một admin của một website có lượng truy cập lớn. Chính vì thế bạn một mình bạn không thể quản lí toàn bộ website được.<br>
Với ZenCMS, bạn không phải lo vì điều đó, bạn chỉ cần phân quyền cho từng thành viên với từng chức vụ khác nhau<br>
Hiện tại ZenCMS có các cấp thành viên như sau: Admin, SMod, Mod, Thành viên bình thường, Thành viên không chính thức và Thành viên bị cấm.<br>
Ngoài ra bạn có thể tạo các chức quyền khác nhau theo ý mình
</div>

	<div class="main_feature_item_holder_new">	
		
		<div class="feature_main_title_new">
Tính tương tác		</div>
		
Bạn đang lo lắng làm sao để biết được ý kiến người đọc về bài viết của mình. Đừng lo bởi vì ZenCMS đã giúp bạn điều đó.<br>
Với ZenCMS bạn không những thể hiện được bài viết của mình cho người khác xem mà bạn còn có thể nhận được phản hồi của người đọc nhờ tính năng comment và like trên bài viết<br>
</div>
	<div class="clear"></div>

	<div class="main_feature_item_holder_new">		
		<div class="feature_main_title_new">
Quản trị thông minh		</div>
		
Admin Cpanel là thành phần không thể thiếu của 1 CMS. <br>
Trong Admin CP bạn sẽ làm được những việc mà thành viên bình thường không làm được như cấu hình website, quản lí module, quản lí widget, chọn template, quản lí thành viên, quản lí cache và các chức năng dành riêng cho Admin
	</div>

	<div class="main_feature_item_holder_new">	
		
		<div class="feature_main_title_new">
Cài đặt đơn giản		</div>

Hướng tới mục tiêu đem lại sự thuận tiện cho người dùng, ZenCMS luôn trực quan hóa những thứ khó hiểu thành những click đơn giản cho người dùng<br/>
Vì vậy bạn không phải lo cài đặt code ra sao, sử dụng như thế nào bởi vì ZenCMS đã giúp bạn làm hết những điều đó		
</div>
	<div class="clear"></div>
	
	
	</div>
	</div>
        
</div>
</div>




<div class="app-wrapper">
<div class="heading">
    <div class="border-heading">
        <i class="icon-new"></i>
        <span>Những ai đang sử dụng ZenCMS</span>
    </div>
</div>

<?php load_layout('banner') ?>

</div>


</div>
</div>



</div>
</div>
</div>

<?php load_layout('left_sidebar') ?>

<?php load_footer() ?>