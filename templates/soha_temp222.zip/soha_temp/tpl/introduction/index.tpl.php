<?php load_header() ?>

<div class="mainContent">
<div class="mainContentWrapper">
<div class="navigationBar">

</div>
<div class="contentContainer" id="bodyContainer">


<!--Body content-->
<div id="homeContainer">

<?php load_layout('sliderbar') ?>

<div class="app-container">


<div id="get_zencms_now">
    <a href="<?php echo _HOME ?>/download/version/400" class="link">
    	Tải ngay ZenCMS 400
    </a>
    <div class="sub_get_zencms">It's free and always will be</div>
</div>
	

<div class="app-wrapper padding20">
<h3 class="intro_title">Trở thành Wapmaster ngay hôm nay</h3>
<div class="container">

<table width="100%">
	<tr>
		<td width="60%">
			<p class="p-content">
		Bạn đang băn khoăn không biết chọn code nào để phát triển website.<br/>
		Vậy tại sao không thử ngay với ZenCMS. Với các tính năng của ZenCMS, chúng tôi đảm bảo bạn sẽ hài lòng với sự lựa chọn của mình.<br/>
		Chúng tôi có một <a href="http://forum.zencms.vn" target="_blank" title="Diễn đàn hỗ trợ ZenCMS, hỗ trợ code wap">diễn đàn</a> hỗ trợ. Và bạn sẽ không phải lo lắng về vấn đề kĩ thuật bới vì chúng tôi luôn sẵn sàng giúp bạn điều đó
			</p>
		</td>
		
		<td width="40%" style="padding-left: 50px; vertical-align: top;">
			   <ul class="list_tick">
			        <li>Cài đặt dễ dàng</li>
			        <li>Quản lí đơn giản</li>
			        <li>Hoạt động mượt mà</li>
			        <li>Và hoàn toàn miễn phí</li>
			    </ul>
		</td>
	</tr>
</table>
        
</div>
</div>


<div class="app-wrapper">
    <div class="holder">
        <div class="f_sub_1">
            <h3>
                Developer friendly
            </h3>

        </div>
        <div class="f_info_3">

            <div class="f_info_3_c_holder">
                <div class="f_info_3_c">
                    No Encryption
                </div>
                <div class="f_info_3_d_point"></div>
                <div class="f_info_3_d">
                    Vì ZenCMS là một open-source nên chúng tôi hoàn toàn không mã hóa, bạn có thể chỉnh sửa code tùy ý theo ý mình.
                </div>
            </div>

            <div class="f_info_3_c_holder">
                <div class="f_info_3_c">
                    Smart System
                </div>
                <div class="f_info_3_d_point"></div>
                <div class="f_info_3_d">
                    Với hệ thống Smart System bạn sẽ dễ dàng phát triển code mà không cần tác động đến phần lõi hệ thống nhờ các cơ chế như Module, Hook, Core Replacement
                </div>
            </div>

            <div class="f_info_3_c_holder">
                <div class="f_info_3_c">
                    Modules
                </div>
                <div class="f_info_3_d_point"></div>
                <div class="f_info_3_d">
                    Module là một tính năng không thể không nhắc đến của ZenCMS vì nó giúp cho quá trình quản lí và thiết kế ứng dụng dễ dàng hơn
                </div>
            </div>
            
            <div class="f_info_3_c_holder">
                <div class="f_info_3_c">
                    Templates
                </div>
                <div class="f_info_3_d_point"></div>
                <div class="f_info_3_d">
                    Chúng tôi không sử dụng bất kì một loại Template Engine nào trong template của mình, Vì chúng tôi cho rằng đó là bất tiện đối với bạn. Template hoàn toàn sử dụng các ngôn ngữ web thông thường
                </div>
            </div>


            <div class="clear"></div>

        </div>
    </div>
</div>




<div class="app-wrapper">
<div class="heading">
    <div class="border-heading">
        <i class="icon-new"></i>
        <span>Những ai đang sử dụng ZenCMS</span>
    </div>
</div>

<?php load_layout('banner') ?>

</div>



</div>
</div>



</div>
</div>
</div>

<?php load_layout('left_sidebar') ?>

<?php load_footer() ?>