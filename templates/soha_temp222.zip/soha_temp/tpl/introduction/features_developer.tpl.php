<?php load_header() ?>

<div class="holder">
    
    <?php load_layout('mainmenu') ?>

    <div class="new_start_your_website_with_zencms">
        <h1>Tính năng</h1>

        <h2>Với ZenCMS, bạn hoàn toàn có thể:</h2>
    </div>
    
</div>

<div id="body_holder_inner">
<div id="footer_sub_section_main">




<div class="new_feature_holder">
	<div class="holder">

	<div class="main_feature_item_holder_new">	
		
		<div class="feature_main_title_new">
Tạo một ứng dụng riêng cho mình		</div>
		
			
		
Tính năng đặc biệt dành cho developer. Bạn sẽ không cần xây dựng website từ A-Z mà chỉ cần viết một module nhỏ trên nền của ZenCMS</div>

	<div class="main_feature_item_holder_new">	
		
		<div class="feature_main_title_new">
Thiết kế template dễ dàng		</div>
		
Không giống như các open-source khác, bạn sẽ phải biết một "ngôn ngữ" khác thì mới có thể viết template cho mình. ZenCMS đơn thuần chỉ sử dụng PHP, HTML, CSS .. và những ngôn ngữ web thông thường khác để tạo nên 1 template đơn giản, đẹp mắt và dễ dàng kiểm soát
			</div>
	<div class="clear"></div>

	<div class="main_feature_item_holder_new">	
		<div id="secure"><a name="secure"></a></div>
		
		<div class="feature_main_title_new">
Secure		</div>
		
			
		
Developers can create secure Apps and place them on their own servers. You have no worries about the security of your own server as we pass information between your server and the developers App server securely.	</div>

	<div class="main_feature_item_holder_new">	
		<div id="app-store"><a name="app-store"></a></div>
		
		<div class="feature_main_title_new">
App Store		</div>
		
			
		
You can create your very own App store. Your users decide what Apps they want to install and once installed can easily access them from their dashboard or main drop down menu.	</div>
	<div class="clear"></div>

	<div class="main_feature_item_holder_new">	
		<div id="mobile-friendly"><a name="mobile-friendly"></a></div>
		
		<div class="feature_main_title_new">
Mobile Friendly		</div>
		
			
		
Apps are not bound to only be used on your site. Developers can even create mobile Apps and take advantage of the powerful and secure API system we provide.	</div>

	<div class="main_feature_item_holder_new">	
		<div id="fan-page"><a name="fan-page"></a></div>
		
		<div class="feature_main_title_new">
Fan Page		</div>
		
			
		
Each App has their own custom fan page where developers can support and promote their App to your community.	</div>
	<div class="clear"></div>

	<div class="main_feature_item_holder_new">	
		<div id="categorized"><a name="categorized"></a></div>
		
		<div class="feature_main_title_new">
Categorized		</div>
		
			
		
Apps can be categorized in custom categories, which you have full control to edit direct from the AdminCP. We provide an awesome list of default categories to get you started.	</div>
	<div class="clear"></div>
	

	
	
	</div>
	</div>




<div class="footer_main_holder footer_main_holder_1 footer_main_holder_first">
    <div class="holder">
        <h2>
            Open-Source
        </h2>

        <h3>Hoàn toàn miễn phí và mãi mãi là như vậy</h3>

        <div class="f_info">
            <div class="f_info_content">
                <div class="f_info_sub">
                    <div class="f_info_title">
                        Trở thành webmaster cùng ZenCMS
                    </div>
                    Bạn đang băn khoăn không biết chọn code nào để phát triển website.<br/>
                    Vậy tại sao không thử ngay với ZenCMS. Với các tính năng của ZenCMS, chúng tôi đảm bảo bạn sẽ hài lòng với sự lựa chọn của mình<br/>
                    Chúng tôi có một <a href="htp://basic.zencms.vn" title="Diễn đàn ZenCMS">diễn đàn</a> hỗ trợ. Và bạn sẽ không phải lo lắng về vấn đề kĩ thuật bới vì chúng tôi luôn sẵn sàng giúp bạn điều đó
                </div>
                <div class="f_info_ul">
                    <ul>
                        <li>Cài đặt dễ dàng</li>
                        <li>Quản lí đơn giản</li>
                        <li>Hoạt động mượt mà</li>
                        <li>Và hoàn toàn miễn phí</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="footer_main_holder footer_main_holder_2">
    <div class="holder">
        <div class="f_sub_2">
            <h2>
                Bạn là ai?
            </h2>

            Yếu tố quan trọng nhất của một open-source đó là sự linh hoạt trong quá trình sử dụng. <br/>
                    Với ZenCMS bạn sẽ có một môi trường làm việc giống như một "mini-framework".<br/>
                     - Nếu bạn là một người sử dụng bình thường bạn chỉ cần cài đặt và sử dụng.<br/>
                     - Còn nếu bạn là một nhà phát triển (Developer) thì bạn hãy tự phát triển cho mình những module riêng và gửi lên "Market" của chúng tôi và chúng tôi sẽ giúp bạn phát triển nó
        </div>
        <div class="f_sub_2_left">
        <h3>User</h3>
            <ul>
                <li>Một Blog game, truyện ..</li>
                <li>Một Forum</li>
                <li>Một trang tán gẫu</li>
                <li>Hay một blog cá nhân</li>
            </ul>
        </div>
        <div class="f_sub_2_right">
        <h3>Developers</h3>
            <ul>
                <li>Phát triển module</li>
                <li>Thiết kế template</li>
                <li>Viết ứng dụng</li>
                <li class="last">Và còn nhiều hơn thế</li>
            </ul>
        </div>
    </div>
</div>

<div class="footer_main_holder footer_main_holder_1 footer_main_holder_dark">
    <div class="holder">
        <div class="f_sub_1">
            <h2>
                Developer friendly
            </h2>

            <h3>Built to be customized to suite your specific needs and niche.</h3>
        </div>
        <div class="f_info_3">

            <div class="f_info_3_c_holder">
                <div class="f_info_3_c">
                    No Encryption
                </div>
                <div class="f_info_3_d_point"></div>
                <div class="f_info_3_d">
                    Vì ZenCMS là một open-source nên chúng tôi hoàn toàn không mã hóa, bạn có thể chỉnh sửa code tùy ý theo ý mình.
                </div>
            </div>

            <div class="f_info_3_c_holder">
                <div class="f_info_3_c">
                    Smart System
                </div>
                <div class="f_info_3_d_point"></div>
                <div class="f_info_3_d">
                    Với hệ thống Smart System bạn sẽ dễ dàng phát triển code mà không cần tác động đến phần lõi hệ thống nhờ các cơ chế như Module, Hook, Core Replacement
                </div>
            </div>

            <div class="f_info_3_c_holder">
                <div class="f_info_3_c">
                    Modules
                </div>
                <div class="f_info_3_d_point"></div>
                <div class="f_info_3_d">
                    Module là một tính năng không thể không nhắc đến của ZenCMS vì nó giúp cho quá trình quản lí và thiết kế ứng dụng dễ dàng hơn
                </div>
            </div>
            
            <div class="f_info_3_c_holder">
                <div class="f_info_3_c">
                    Templates
                </div>
                <div class="f_info_3_d_point"></div>
                <div class="f_info_3_d">
                    Template là yếu tố không thể thiếu của một open-source. Chúng tôi không sử dụng bất kì một loại Template Engine nào trong template của mình, Vì chúng tôi cho rằng đó là bất tiện đối với bạn. Template hoàn toàn sử dụng các ngôn ngữ web thông thường
                </div>
            </div>



            <div class="clear"></div>

        </div>
    </div>
</div>


</div>


<?php load_footer() ?>