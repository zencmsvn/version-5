<?php load_header() ?>

<div class="mainContent">
<div class="mainContentWrapper">
<div class="navigationBar">

</div>
<div class="contentContainer" id="bodyContainer">


<!--Body content-->
<div id="homeContainer">
    

<div class="app-container">
	

<div class="app-wrapper">
<div class="breadcrumb"><?php echo $display_tree; ?></div>
<div class="heading">
    <div class="border-heading">
        <i class="icon-new"></i>
        <span><?php echo $blog['name']; ?></span>
    </div>
</div>
<div class="container">

<?php load_layout('blog_share') ?>

<?php load_layout('blog_manager_bar', true) ?>
        
<div class="content">

<?php echo $blog['content']; ?>

</div>

<?php if (!empty($blog['downloads'])): ?>
<?php load_layout('blog_download') ?>
<?php endif ?>

<?php if (!empty($blog['tags'])): ?>
<?php load_layout('blog_tag') ?>
<?php endif ?>

<?php load_layout('blog_comments') ?>

</div>
</div>


<div class="app-wrapper">
    
</div>




<div class="app-wrapper">
<div class="heading">
    <div class="border-heading">
        <i class="icon-new"></i>
        <span>Những ai đang sử dụng ZenCMS</span>
    </div>
</div>

<?php load_layout('banner') ?>

</div>



</div>
</div>



</div>
</div>
</div>

<?php load_layout('blog_left_sidebar') ?>

<?php load_footer() ?>