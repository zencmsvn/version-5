<?php load_header() ?>

    <div class="mainContent">
        <div class="mainContentWrapper">
            <div class="navigationBar">

            </div>
            <div class="contentContainer" id="bodyContainer">

                <!--Body content-->
                <div id="homeContainer">

                    <div class="app-container">

                        <?php if (count($list['new_posts'])): ?>
                            <div class="app-wrapper">
                                <div class="heading">
                                    <div class="border-heading">
                                        <i class="icon-new"></i>
                                        <span>Mới nhất</span>
                                    </div>
                                </div>

                                <div class="container">
                                    <?php foreach ($list['new_posts'] as $new): ?>

                                        <a href="<?php echo $new['full_url']; ?>" title="<?php echo $new['title']; ?>">
                                            <div class="item">
                                                <?php echo icon('item'); ?><?php echo $new['name']; ?>
                                                <span class="text_smaller gray">
		                                             <i>(<?php echo get_time($new['time'], false) ?>)</i>
		                                        </span>
                                            </div>
                                        </a>

                                    <?php endforeach; ?>
                                </div>

                            </div>
                        <?php endif ?>


                        <?php if (count($list['hot_posts'])): ?>

                            <div class="app-wrapper">
                                <div class="heading">
                                    <div class="border-heading">
                                        <i class="icon-hot"></i>
                                        <span>Xem nhiều nhất</span>
                                    </div>
                                </div>

                                <div class="container">
                                    <?php foreach ($list['hot_posts'] as $hot): ?>
                                        
                                        <a href="<?php echo $hot['full_url']; ?>" title="<?php echo $hot['title']; ?>">
                                            <div class="item">
                                                <?php echo icon('view', 'vertical-align: middle;') ?> <?php echo $hot['name']; ?>
                                                <span class="text_smaller gray">
                                                    <i><?php echo $hot['view'] ?></i>
                                                </span>
                                            </div>
                                        </a>
                                        
                                    <?php endforeach; ?>
                                </div>

                            </div>

                        <?php endif ?>

                        <?php if (empty($cats)): ?>

                            <div class="app-wrapper">
                                <div class="notice">
                                    Hiện tại chưa có bài viết nào.
                                    <?php if (is(ROLE_MANAGER)): ?>
                                        <br/>Click vào <b><a href="<?php echo _HOME ?>/blog/manager/cpanel">đây</a></b> và bắt đầu thêm nội dung
                                    <?php endif ?>
                                </div>
                            </div>

                        <?php else: ?>

                            <?php foreach ($cats as $id => $cat): ?>

                                <?php if (!empty($cat['sub_cat'])): ?>

                                    <div class="app-wrapper">

                                        <div class="heading">
                                            <div class="border-heading">
                                                <i class="icon-new"></i>
                                                <span>
                                                    <?php echo $cat['name']; ?>
                                                </span>
                                            </div>
                                        </div>

                                        <div class="container">

                                            <?php foreach ($cat['sub_cat'] as $sub_cat): ?>

                                                <a href="<?php echo $sub_cat['full_url']; ?>" title="<?php echo $sub_cat['title']; ?>">
                                                    <div class="item">
                                                        <?php echo icon('item'); ?><?php echo $sub_cat['name']; ?>
                                                    </div>
                                                </a>
                                                
                                            <?php endforeach; ?>

                                        </div>

                                    </div>

                                <?php endif; ?>

                            <?php endforeach; ?>

                        <?php endif ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php load_layout('left_sidebar') ?>

<?php load_footer() ?>