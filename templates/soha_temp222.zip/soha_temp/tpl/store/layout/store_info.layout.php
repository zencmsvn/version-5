<div class="post_detail">
    <span class="view text_smaller gray">Bởi <?php echo show_nick($store['uid'], true) ?>, <?php echo icon('view', 'vertical-align: text-bottom;') ?> <?php echo $store['view'] ?></span><br/>
    <span class="like"><?php echo $store['likes'] ?></span> <?php echo $store['link_like'] ?>
    <?php echo $store['link_dislike'] ?> <span class="like"><?php echo $store['dislikes'] ?></span>
</div>