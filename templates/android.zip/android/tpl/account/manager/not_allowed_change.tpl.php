<?php load_header() ?>

    <h1 class="title border_orange">Quản lí chức vụ</h1>
    <div class="breadcrumb"><?php echo $display_tree ?></div>

    <div class="detail_content">
        <h2 class="title border_blue">Lỗi</h2>
        <?php load_message() ?>
        <div class="item">
            Bạn không thể làm điều này
        </div>
    </div>

<?php load_footer() ?>