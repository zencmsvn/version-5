<?php load_header() ?>
    <div class="detail_content">
        <h1 class="title"><?php echo $page_title ?></h1>
        <?php load_message() ?>
    </div>
<?php load_footer() ?>