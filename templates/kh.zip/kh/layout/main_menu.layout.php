<div class="navigationBar">
    <i class="icon-menu"></i>Danh mục
</div>
<ul class="sidebar_item">

    <a href="<?php echo _HOME ?>">
        <li>Trang chủ</li>
    </a>
    <a href="<?php echo _HOME ?>/download">
        <li>Tải về</li>
    </a>
    <a href="<?php echo _HOME ?>/huong-dan-su-dung-2.html">
        <li>Hướng dẫn</li>
    </a>
    <a href="<?php echo _HOME ?>/introduction/features">
        <li>Tính năng</li>
    </a>
    <a href="<?php echo _HOME ?>/introduction/features">
        <li>Features for developers</li>
    </a>

</ul>
