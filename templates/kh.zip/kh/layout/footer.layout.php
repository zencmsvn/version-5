</tr>
</table>
</div>

<div class="footer">
    <table>
        <tr>
            <td>
                BẢN QUYỀN THUỘC VỀ <b>ZENCMS</b><br/>
                &copy; 2013 <a href="http://zenthang.com" title="ZenThang">ZenThang</a>
            </td>
            <td width="50%" align="right">
                <span><a href="<?php echo _HOME ?>">TRANG CHỦ</a></span> /
                <span><a href="<?php echo _HOME ?>/blog">HƯỚNG DẪN SỬ DỤNG</a></span> /
                <span><a href="<?php echo _HOME ?>/developer-documentation-1.html">DEVELOPER DOCUMMENT</a></span>
                <span><a href="<?php echo _HOME ?>/license">Điều khoản sử dụng</a></span>

                <div>
                    Liên hệ: <b><a href="tel:01686298448">01686298448</a></b> - <b>thangangle@yahoo.com</b>
                </div>
            </td>
        </tr>
    </table>
</div>
</div>

</body>
</html>